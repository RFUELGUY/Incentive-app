import React, { useState } from "react";
import Sidebar from "./Sidebar";
import OutletManager from "./OutletManager";
import PendingSalesmen from "./PendingSalesmen";
import UserManager from "./UserManager";
import BaseUpload from "./BaseUpload";
import ProductManager from "./ProductManager";
import SalesUpload from "./SalesUpload";
import ClaimDashboard from "./ClaimDashboard";
import IncentiveControl from "./IncentiveControl";
import Streaks from "./Streaks";
import Leaderboard from "./Leaderboard";
import TraitsConfig from "./TraitsConfig";
import SetupPanel from "./SetupPanel";

const AdminDashboard = () => {
  const [activeSection, setActiveSection] = useState("dashboard");
  const [refreshKey, setRefreshKey] = useState(0);

  const renderSection = () => {
    const props = { key: refreshKey };

    switch (activeSection) {
      case "outlets": return <OutletManager {...props} />;
      case "pending": return <PendingSalesmen {...props} />;
      case "users": return <UserManager {...props} />;
      case "upload": return <BaseUpload {...props} />;
      case "products": return <ProductManager {...props} />;
      case "sales": return <SalesUpload {...props} />;
      case "claims": return <ClaimDashboard {...props} />;
      case "incentives": return <IncentiveControl {...props} />;
      case "streaks": return <Streaks {...props} />;
      case "leaderboard": return <Leaderboard {...props} />;
      case "traits": return <TraitsConfig {...props} />;
      case "setup": return <SetupPanel {...props} />;
      default:
        return <div className="text-xl font-semibold">Welcome to Admin Dashboard</div>;
    }
  };

  return (
    <div className="flex h-screen overflow-hidden">
      <Sidebar activeSection={activeSection} setActiveSection={setActiveSection} />
      <div className="flex-1 p-4 overflow-y-auto">
        {renderSection()}
      </div>
    </div>
  );
};

export default AdminDashboard;
